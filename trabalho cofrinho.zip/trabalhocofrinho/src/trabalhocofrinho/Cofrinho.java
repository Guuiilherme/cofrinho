package trabalhocofrinho;

import java.util.ArrayList;

class Cofrinho {
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();
    }

    public void adicionarMoeda(Moeda m) {
        moedas.add(m);
    }

    public void removerMoeda(Moeda m) {
        moedas.remove(m);
    }

    public void listarMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("O cofrinho está vazio.");
        } else {
            for (Moeda m : moedas) {
                System.out.println(m);
            }
        }
    }

    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda m : moedas) {
            total += m.converterParaReal();
        }
        return total;
    }
}
