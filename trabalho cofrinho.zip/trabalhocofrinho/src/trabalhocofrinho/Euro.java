package trabalhocofrinho;

class Euro extends Moeda {

    public Euro(double valor) {
        super(valor, "União Europeia");
    }

    @Override
    public double converterParaReal() {
        return valor * 6.00;
    }

    @Override
    public String toString() {
        return "Euro: " + valor + " EUR";
    }
}

