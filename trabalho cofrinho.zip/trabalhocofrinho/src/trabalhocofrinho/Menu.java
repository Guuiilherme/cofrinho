package trabalhocofrinho;

import java.util.Scanner;

public class Menu {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int opcao;

        do {
            System.out.println("\nMenu do Cofrinho:");
            System.out.println("1. Adicionar moeda");
            System.out.println("2. Remover moeda");
            System.out.println("3. Listar moedas");
            System.out.println("4. Calcular total em reais");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Escolha a moeda para adicionar: ");
                    System.out.println("1. Dólar");
                    System.out.println("2. Euro");
                    System.out.println("3. Real");
                    int tipoMoeda = scanner.nextInt();
                    System.out.print("Digite o valor da moeda: ");
                    double valor = scanner.nextDouble();

                    Moeda novaMoeda = null;
                    if (tipoMoeda == 1) {
                        novaMoeda = new Dolar(valor);
                    } else if (tipoMoeda == 2) {
                        novaMoeda = new Euro(valor);
                    } else if (tipoMoeda == 3) {
                        novaMoeda = new Real(valor);
                    }

                    if (novaMoeda != null) {
                        cofrinho.adicionarMoeda(novaMoeda);
                        System.out.println("Moeda adicionada com sucesso!");
                    }
                    break;

                case 2:
                    System.out.println("Remover uma moeda (não implementado totalmente para fins de simplicidade)");
                    // Exemplo de remoção poderia ser feito com busca por valor ou referência
                    break;

                case 3:
                    System.out.println("Moedas no cofrinho:");
                    cofrinho.listarMoedas();
                    break;

                case 4:
                    System.out.println("Total em reais: " + cofrinho.calcularTotalEmReais());
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");
                    break;
            }

        } while (opcao != 0);

        scanner.close();
    }
}

