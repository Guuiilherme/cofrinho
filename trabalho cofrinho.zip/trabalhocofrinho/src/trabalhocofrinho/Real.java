package trabalhocofrinho;

class Real extends Moeda {

    public Real(double valor) {
        super(valor, "Brasil");
    }

    @Override
    public double converterParaReal() {
        return valor; 
    }

    @Override
    public String toString() {
        return "Real: " + valor + " BRL";
    }
}

