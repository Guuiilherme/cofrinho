package trabalhocofrinho;

class Dolar extends Moeda {

    public Dolar(double valor) {
        super(valor, "EUA");
    }

    @Override
    public double converterParaReal() {
        return valor * 5.30;
    }

    @Override
    public String toString() {
        return "Dólar: " + valor + " USD";
    }
}

