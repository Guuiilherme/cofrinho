/**
 * 
 */
/**
 * 
 */
module trabalhocofrinho {
}